#ifndef __SYS_PROJECT_CONFIG_H__
#define __SYS_PROJECT_CONFIG_H__
#define SYS_WIFI_MODE       WIFI_MODE_AP
#define SYS_APP_DHCPD       1
#define SYS_APP_WNBOTA      1
#define SYS_APP_NETAT       1
#define SYS_APP_NETLOG      1
#define SYS_DHCPD_EN        1

#define WIFI_REPEATER_SUPPORT 0  //=0不支持中继；如果=1支持中继，参数区会发生变化，升级固件要恢复出厂

#define WIFI_PSALIVE_SUPPORT 1   //支持标准协议的psmode2（服务器保活）
//#define SKB_TRACE

//#define SYS_STA_MAX (31)         //不打开这个宏，最大支持8sta；打开则最大支持31 sta；不能支持更多sta了
//#define DUAL_ANT_OPT             //使能双天线
//#define ROLE_KEY_EN  0           //不需要角色IO的时候，打开这个宏

#define SYS_APP_UART_P2P    0       //=1，打开uart透传
//#define DIS_BOOT_PRINT            //关闭开机打印
#define UART_P2P_TIMER      HG_TIMER2_DEVID
#define UART_P2P_DEV        HG_UART1_DEVID
#define UART_P2P_BAUDRATE   115200  //波特率默认115200，范围9600-400k



#endif
