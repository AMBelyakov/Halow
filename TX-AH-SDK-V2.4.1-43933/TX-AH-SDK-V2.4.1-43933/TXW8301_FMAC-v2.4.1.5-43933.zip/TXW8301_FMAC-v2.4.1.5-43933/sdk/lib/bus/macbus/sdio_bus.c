#include "sys_config.h"
#include "typesdef.h"
#include "list.h"
#include "dev.h"
#include "devid.h"
#include "osal/string.h"
#include "osal/mutex.h"
#include "osal/semaphore.h"
#include "osal/task.h"
#include "osal/timer.h"
#include "hal/sdio_slave.h"
#include "hal/gpio.h"
#include "lib/skb/skb.h"
#include "lib/bus/macbus/mac_bus.h"
#include "lib/lmac/hgic.h"

struct mac_bus_sdio {
    struct mac_bus     bus;
    struct sdio_slave *dev;
    uint16 part_len;
    uint16 pkt_len;
    uint8 *rx_buf;
};

static void sdio_bus_set_busy(struct mac_bus_sdio *sdio_bus, uint32 busy)
{
    //gpio_set_val(PA_8, busy);
    sdio_slave_ioctl(sdio_bus->dev, SDIO_SLAVE_IO_CMD_SET_USER_REG1, busy);
}

static int32 sdio_bus_write(struct mac_bus *bus, uint8 *buff, int32 len)
{
    int32 ret = RET_OK;
    struct mac_bus_sdio *sdio_bus = container_of(bus, struct mac_bus_sdio, bus);

    ret = sdio_slave_write(sdio_bus->dev, buff, ALIGN(len, 4), TRUE);
    if (ret) {
        sdio_bus->bus.txerr++;
    }
    return ret;
}

static int32 sdio_bus_write_scatter(struct mac_bus *bus, scatter_data *data, int count)
{
    int32 ret = RET_OK;
    struct mac_bus_sdio *sdio_bus = container_of(bus, struct mac_bus_sdio, bus);

    ret = sdio_slave_write_scatter(sdio_bus->dev, data, count, TRUE);
    if (ret) {
        sdio_bus->bus.txerr++;
    }
    return ret;
}

static void sdio_bus_irq(uint32 irq, uint32 param1, uint32 param2, uint32 param3)
{
    struct mac_bus_sdio *sdio_bus = (struct mac_bus_sdio *)param1;
#ifdef SDIO_PART_TRANS
    struct hgic_hdr *hdr = (struct hgic_hdr *)sdio_bus->rx_buf;
#endif
    int32  ret = 0;
    //gpio_set_val(1, 1);
    switch (irq) {
        case SDIO_SLAVE_IRQ_RX:
#ifdef SDIO_PART_TRANS
            if (sdio_bus->part_len == 0 && hdr->magic == HGIC_HDR_TX_MAGIC && param3 < hdr->length) {
                sdio_bus->part_len = param3;
                break;
            }
            if (sdio_bus->part_len > 0) { param3 += sdio_bus->part_len; }
            sdio_bus->part_len = 0;
#endif
            ret = sdio_bus->bus.recv(&sdio_bus->bus, sdio_bus->rx_buf, param3);
            if (ret) {
                if (ret == -ENOMEM) {
                    sdio_bus_set_busy(sdio_bus, 1);
                }
                sdio_bus->bus.rxerr++;
            } else {
                ret = skbpool_freesize(1) < sdio_bus->pkt_len;
                sdio_bus_set_busy(sdio_bus, ret);
            }
            sdio_slave_read(sdio_bus->dev, sdio_bus->rx_buf, sdio_bus->pkt_len, FALSE);
            break;
        case SDIO_SLAVE_IRQ_RESET:
            sdio_slave_read(sdio_bus->dev, sdio_bus->rx_buf, sdio_bus->pkt_len, FALSE);
            //gpio_set_dir(PC_1, GPIO_DIR_OUTPUT);
            //gpio_set_dir(PC_2, GPIO_DIR_OUTPUT);
            //gpio_set_dir(PA_8, GPIO_DIR_OUTPUT);
            break;
        default:
            break;
    }
    //gpio_set_val(1, 0);
}

static int32 sdio_bus_ioctl(struct mac_bus *bus, uint32 cmd, uint32 param1, uint32 param2)
{
    int32 ret = -ENOTSUPP;
    struct mac_bus_sdio *sdio_bus = container_of(bus, struct mac_bus_sdio, bus);
    switch (cmd) {
        case MACBUS_IOCTL_BUFFER_IDLE:
            sdio_bus_set_busy(sdio_bus, 0);
        default:
            break;
    }
    return ret;
}

__init struct mac_bus *mac_bus_sdio_attach(mac_bus_recv recv, void *priv, uint16 drv_aggsize)
{
    int32  ret = RET_OK;
    struct mac_bus_sdio *sdio_bus;
    struct sdio_slave *sdio = (struct sdio_slave *)dev_get(HG_SDIOSLAVE_DEVID);

    if (sdio == NULL) {
        return NULL;
    }

    sdio_bus = os_zalloc(sizeof(struct mac_bus_sdio));
    ASSERT(sdio_bus && recv);
    sdio_bus->bus.write = sdio_bus_write;
#ifdef DMA_SCATTER_COUNT
    sdio_bus->bus.write_scatter = sdio_bus_write_scatter;
#endif
    sdio_bus->bus.ioctl = sdio_bus_ioctl;
    sdio_bus->bus.type  = MAC_BUS_TYPE_SDIO;
    sdio_bus->bus.recv  = recv;
    sdio_bus->bus.priv  = priv;
    sdio_bus->dev       = sdio;
    sdio_bus->pkt_len   = drv_aggsize > 2048 ? drv_aggsize : 2048;
    sdio_bus->rx_buf    = os_malloc(sdio_bus->pkt_len);
    ASSERT(sdio_bus->rx_buf);
    ret = sdio_slave_open(sdio_bus->dev, SDIO_SLAVE_SPEED_48M, 0); //SDIO_SLAVE_SPEED_4M
    sdio_slave_read(sdio_bus->dev, sdio_bus->rx_buf, sdio_bus->pkt_len, FALSE);
    sdio_slave_request_irq(sdio_bus->dev, sdio_bus_irq, (uint32)sdio_bus);
    os_printf("SDIO bus init done, ret = %d\r\n", ret);
    //gpio_set_dir(PC_1, GPIO_DIR_OUTPUT);
    //gpio_set_dir(PC_2, GPIO_DIR_OUTPUT);
    //gpio_set_dir(PA_8, GPIO_DIR_OUTPUT);
    return &sdio_bus->bus;
}

void mac_bus_sdio_detach(struct mac_bus *bus)
{
    struct sdio_slave *sdio = (struct sdio_slave *)dev_get(HG_SDIOSLAVE_DEVID);
    if (sdio) {
        sdio_slave_close(sdio);
    }
}

